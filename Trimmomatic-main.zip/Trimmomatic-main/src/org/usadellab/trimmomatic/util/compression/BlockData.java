package org.usadellab.trimmomatic.util.compression;

public interface BlockData
{
	public byte[] getData();
}
